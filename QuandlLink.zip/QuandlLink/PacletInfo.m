(* Paclet Info File *)

(* created 2015.06.23*)

Paclet[
  Name -> "QuandlLink",
  Version -> "0.0.1",
  MathematicaVersion -> "6+",
  Extensions -> {
  	{
  		"Kernel",
  		 Context -> {"QuandlLink`"}
            }, 
    {"Documentation", Language -> "English", LinkBase -> "QuandlFinancialData"}
}]