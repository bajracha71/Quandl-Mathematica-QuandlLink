(* Wolfram Language Init File *)

Get[ "QuandlLink`QuandlLink`"]